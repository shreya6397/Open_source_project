from tkinter import *
from subprocess import call
import subprocess
from tkinter.ttk import *
from tkinter import ttk

class sambaUser:
	def __init__(self, master):
		self.master = master
		self.nb=ttk.Notebook(self.master,height=200,width=350)
		
		# install frame
		self.install=ttk.Frame(self.nb)
		self.label = Label(self.install, text="Install samba from here!")
		self.label.grid(row=0,column=0,pady=1,padx=1)
		
		self.install_btn = Button(self.install, text="INSTALL", command=self.instal)
		self.install_btn.grid(row=1,column=0,padx=2,pady=2)

		self.close_button = Button(self.master, text="Close", command=self.close_window)
		self.close_button.grid(row=1,column=1,pady=3)

		self.nb.add(self.install,text='Install')
		self.nb.grid(row=0,column=0)

	def instal(self):

		# subprocess.call(["dnf install", "samba", "samba-client", "cifs-utils -y"])
		ref=subprocess.Popen('date')
		self.date1=Label(self.install,text=ref)
		self.date1.grid(row=3,column=0,padx=2,pady=2)

	def close_window(self):
		self.master.destroy()

