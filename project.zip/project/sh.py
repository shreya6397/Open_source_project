from tkinter import *

class Application(Frame):
 def __init__(self,master):
  Frame.__init__(self,master)
  self.grid()
  #self.title("Create samba share")
  self.create_widgets()
 
 def create_widgets(self):
  self.instruction = Label(self, text = "Directory :")
  self.instruction.grid(row = 0, column = 0, columnspan = 3, sticky = W, padx = 10, pady = 10)
  self.text = Entry(self)
  self.text.grid(row = 0, column = 3,  sticky = E, padx = 10, pady = 10)
  
  self.instruction3 = Button(self, text = "Browse")
  self.instruction3.grid(row = 0, column = 7, sticky = E)  

  self.instruction1 = Label(self, text = "Share name :")
  self.instruction1.grid(row = 2, column = 0, columnspan = 3, sticky = W, padx = 10, pady = 10)
  self.text1 = Entry(self)
  self.text1.grid(row = 2, column = 3, sticky = W, padx = 10, pady = 10)
  
  self.instruction2 = Label(self, text = "Description :")
  self.instruction2.grid(row = 3, column =0, columnspan = 3, sticky = W, padx = 10, pady = 10)
  self.text2 = Entry(self)
  self.text2.grid(row = 3, column = 3, sticky = W, padx =10, pady = 10)
  
  self.instruction4 = Button(self, text= "Cancel")
  self.instruction4.grid(row = 5, column = 3, sticky = E)

  self.instruction5 = Button(self, text = "OK")
  self.instruction5.grid(row = 5, column = 5, sticky = E)
  
  self.instruction6 = Checkbutton(self, text = "Writable")
  self.instruction6.grid(row = 5, column = 2, sticky = E)
  
  self.instruction7 = Checkbutton(self, text = "Visible")
  self.instruction7.grid(row = 6, column = 2, sticky = E)
  
  


root = Tk()
root.geometry("550x250")
app = Application(root)
root.mainloop()
