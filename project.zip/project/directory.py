from tkinter import *
from tkinter.ttk import *
from tkinter import ttk
from tkinter import font

#v=IntVar()


class Serversettings:
	def __init__(self, master):
		self.master = master
		self.nb=ttk.Notebook(self.master)

		# Basic frame
		self.basic=ttk.Frame(self.nb)
		
		self.directory=Label(self.basic,text="Directory: ",font='bold')
		self.directoryname=Entry(self.basic,width=25)
		self.browsebtn=Button(self.basic, text = "Browse")
		self.share=Label(self.basic, text = "Share name :",font='bold')
		self.sharename=Entry(self.basic,width=25)
		self.desc=Label(self.basic, text = "Description :",font='bold')
		self.descentry=Entry(self.basic,width=25)
E
		
		self.writedir=Checkbutton(self.basic, text = "Writable")
		self.visibledir=Checkbutton(self.basic, text = "Visible ")

		self.cancelbtn= Button(self.master, text= "Cancel", command=self.close_window)
		
		#directory code here
		self.okbtn= Button(self.master, text= "Ok")

		
		self.directory.grid(row=0,column=0,pady=4,padx=2)
		self.directoryname.grid(row=0,column=1,pady=4,padx=1)
		self.browsebtn.grid(row=0,column=2,pady=4,padx=5)
		self.share.grid(row=1,column=0,pady=2,padx=3)
		self.sharename.grid(row=1,column=1,pady=2,padx=2)
		self.desc.grid(row=2,column=0,pady=2,padx=3)
		self.descentry.grid(row=2,column=1,padx=2,pady=2)
		self.writedir.grid(row=3,column=0,padx=2,pady=4)
		self.visibledir.grid(row=4,column=0,padx=1,pady=4)
		self.cancelbtn.grid(row=1,column=0,pady=2,ipadx=2)
		self.okbtn.grid(row=1,column=1,pady=2,ipadx=2)

		#Access frame
		self.access=ttk.Frame(self.nb)
		self.v=IntVar()
		self.onlyaccess=Radiobutton(self.access, text="Only allow access to specific users", variable=self.v, value=1)
		self.everyone=Radiobutton(self.access, text="allow access to everyone", variable=self.v, value=2)
		self.usrgrp=Frame(self.access,width=100,height=70)
		self.usr1=Checkbutton(self.usrgrp,text='nobody')
		self.usr1.grid(row=0,column=0,padx=2,pady=2)
		self.onlyaccess.grid(row=0,column=0,pady=2)
		self.usrgrp.grid(row=1,column=0,pady=2)
		self.everyone.grid(row=2,column=0,pady=2)

		self.nb.add(self.basic,text='Basic')
		self.nb.add(self.access,text='Access')
		self.nb.grid(row=0,column=0)

	def close_window(self):
		self.master.destroy()



