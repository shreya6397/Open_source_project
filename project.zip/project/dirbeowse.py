from tkinter import *
import os

LARGE_FONT = ("Verdana", 12)
current_dir = os.getcwd()


class Gui(Tk):

 def __init__(self, *args, **kwargs):
    Tk.__init__(self, *args, **kwargs)

    Tk.wm_title(self, "My controls")

    container = Frame(self)
    container.pack(side="top", fill="both", expand=True)
    container.grid_rowconfigure(0, weight=1)
    container.grid_columnconfigure(0, weight=1)

    self.geometry("350x500")

    self.frames = {}

    frame = StartPage(container, self)

    self.frames[StartPage] = frame

    frame.grid(row=0, column=0, sticky="nsew")

    self.show_frame(StartPage)

 def show_frame(self, cont):

    frame = self.frames[cont]
    frame.tkraise()


class StartPage(Frame):

 def __init__(self, parent, controller):
    Frame.__init__(self, parent)
    label = Label(self, text="My controls",     font=LARGE_FONT)
    label.pack(pady=10, padx=10)
    self.buttons()
    self.program = ""

 #Defining the browsebutton, any suggestions on what I should do next?

 def browsedir(self):
    from tkinter.filedialog import askdirectory

    Tk().withdraw()
    self.filename = askdirectory()

#Defining the copying of the files and filepath. How to make the filepath variable?*

def runanalyze1(filepath):
  for txt in os.listdir(filepath):
    if txt.endswith('.txt'):
        copyfiles(from_path=filepath+"\\"+txt, to_path=r"C:\catalog"+"\\"+txt)

 def buttons(self):

    self.pack(fill=BOTH, expand=1)
    analyze1button = Button(self, text="Copyfiles", command=self.runanalyze1)
    analyze1button.place(x=50, y=150) 

    quitbutton = Button(self, text="Quit", command=self.quit)
    quitbutton.place(x=150, y=250)

    *#Creating the browse button*

    browsebutton = Button(self, text="Browse", command=self.browsedir)
    browsebutton.pack(side=BOTTOM)

   *#Creating an entry, not sure how to tie this to the browse button either.*

    e1 = Entry(self, bd=5)
    e1.pack(side=BOTTOM)
    e1.insert(0, "{}".format(current_dir))

if __name__ == "__main__":
  app = Gui()
  app.mainloop()
m tkinter import *
import os

LARGE_FONT = ("Verdana", 12)
current_dir = os.getcwd()


class Gui(Tk):

 def __init__(self, *args, **kwargs):
    Tk.__init__(self, *args, **kwargs)

    Tk.wm_title(self, "My controls")

    container = Frame(self)
    container.pack(side="top", fill="both", expand=True)
    container.grid_rowconfigure(0, weight=1)
    container.grid_columnconfigure(0, weight=1)

    self.geometry("350x500")

    self.frames = {}

    frame = StartPage(container, self)

    self.frames[StartPage] = frame

    frame.grid(row=0, column=0, sticky="nsew")

    self.show_frame(StartPage)

 def show_frame(self, cont):

    frame = self.frames[cont]
    frame.tkraise()


class StartPage(Frame):

 def __init__(self, parent, controller):
    Frame.__init__(self, parent)
    label = Label(self, text="My controls",     font=LARGE_FONT)
    label.pack(pady=10, padx=10)
    self.buttons()
    self.program = ""

 *#Defining the browsebutton, any suggestions on what I should do next?**

 def browsedir(self):
    from tkinter.filedialog import askdirectory

    Tk().withdraw()
    self.filename = askdirectory()

*#Defining the copying of the files and filepath. How to make the filepath variable?

def runanalyze1(filepath):
  for txt in os.listdir(filepath):
    if txt.endswith('.txt'):
        copyfiles(from_path=filepath+"\\"+txt, to_path=r"C:\catalog"+"\\"+txt)

 def buttons(self):

    self.pack(fill=BOTH, expand=1)
    analyze1button = Button(self, text="Copyfiles", command=self.runanalyze1)
    analyze1button.place(x=50, y=150) 

    quitbutton = Button(self, text="Quit", command=self.quit)
    quitbutton.place(x=150, y=250)

    #Creating the browse button

    browsebutton = Button(self, text="Browse", command=self.browsedir)
    browsebutton.pack(side=BOTTOM)

   #Creating an entry, not sure how to tie this to the browse button either.

    e1 = Entry(self, bd=5)
    e1.pack(side=BOTTOM)
    e1.insert(0, "{}".format(current_dir))

if __name__ == "__main__":
  app = Gui()
  app.mainloop()
